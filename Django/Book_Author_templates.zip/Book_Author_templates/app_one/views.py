from django.shortcuts import render , redirect
from . import models

def index (request):
    context = {
        "show_books" : models.show_book()
    }
    return render(request , "books.html" , context)

def processing(request):
    models.add_book(request)
    return redirect('/')

def view_desc(request , id):
    context = {
        "id" : id , 
        "show_books" : models.show_book()
    }
    return render(request , 'bookView.html' , context)

