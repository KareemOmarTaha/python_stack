from django.db import models

class Book(models.Model):
    title = models.CharField(max_length=255)
    decription= models.TextField(default="empty")
    created_at = models.DateTimeField(auto_now_add=True)
    created_at = models.DateTimeField(auto_now=True)


class Author(models.Model):
    first_name = models.CharField(max_length=45)
    last_name = models.CharField(max_length=45)
    notes = models.TextField(default="Nothing")
    books = models.ManyToManyField(Book , related_name="authors")
    created_at = models.DateTimeField(auto_now_add=True)
    created_at = models.DateTimeField(auto_now=True)

def show_book():
    book_name = Book.objects.all()
    return book_name
    
def add_book(request):
    new_book = Book.objects.create(title=request.POST['book_title'],decription = request.POST['book_desc'])
    return new_book

