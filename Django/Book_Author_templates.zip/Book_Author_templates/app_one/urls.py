from django.urls import path
from . import views

urlpatterns = [
    path('', views.index ),
    path('process', views.processing ),
    path ('books/<int:id>' , views.view_desc)
]
